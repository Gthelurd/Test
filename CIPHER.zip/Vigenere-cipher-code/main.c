
#include <stdio.h>
#include <string.h>
#include <ctype.h>
//CRYPTO IS SHORT FOR CRYPTOGRAPHY
//CSASXT IT UKSWT GQU GWYQVRKWAQJB
//KEY-word:ABCDEF AB CDEFA BCD EFABCDEFABCD

int   main(void)
{
    char str1 [255];
    char str2 [255];
    char str3 [255];
    //�õ����ĺ���Կ
    printf("Please input your Words here:\n");
    gets(str1);

    printf("Please input your Keywords here:\n");
    gets(str2);
    /*����Կȫ��ת��ΪСд.
    �����õ�����ҳ����������Ŀ��ļ�
    #include <string.h>��δ����strlwr()����,
    ����ѭ��ת��.*/
    int k;
    for(k=0; k<strlen(str2); k++)
    {
        if(str1[k]<='Z'&&str1[k]>='A')
        {
            str2[k]=str2[k]+32;
        }

    }

    //����ѭ������
    int i;
    int j=0;
    for(i=0; i<strlen(str1); i++)
    {
        if(isalpha(str1[i]))
        {
            if(str1[i]<='Z'&&str1[i]>='A')
            {
                str3[i]=((str1[i]-65)+(str2[j]-97))%26;
            }
            else if(str1[i]<='z'&&str1[i]>='a')
            {
                str3[i]=((str1[i]-97)+(str2[j]-97))%26;
            }
            //ѭ����Կ
            j++;
            if(j>=strlen(str2))
            {
                j=0;
            }
        }

    }
    printf("Your Enc is belows:\n\n");
//��ӡ����
    for(i=0; i<strlen(str1); i++)
    {
        if(isalpha(str1[i]))
        {
            if(str1[i]<='Z'&&str1[i]>='A')
            {
                printf("%c",str3[i]+65);
            }
            else if(str1[i]<='z'&&str1[i]>='a')
            {
                printf("%c",str3[i]+97);
            }
        }
        else
        {
            printf("%c",str1[i]);
        }
    }
    printf("\n");
    return 0;
}

