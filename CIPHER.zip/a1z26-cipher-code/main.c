#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
int main(void)
{
    printf("Please input your words\n");
    char str[255]={};
    int a[256]={0};
    gets(str);
    strlwr(str);
    int i=0;
    int j=0;
    for(i=0;i<strlen(str);i++)
    {
        if(isalpha(str[i])){
        a[j]=str[i]-'a'+1;
        j++;}
    }

    for(i=0;i<j;i++)
    {
 printf("%d",a[i]);
 if(i!=j-1){
 printf("-");}
    }
    return 0;
}
