#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	char a[255];
	printf("your code:");
	gets(a);

	int len=strlen(a),i,j,count=0,wei[100],num[100]={0},times=0;
	int ctoi=0,befctoi=0;
	for(i=0;i<len+1;i++)
	{
		if(a[i]>='0'&&a[i]<='9')
		{
			ctoi=1;
		}
		else
		{
			ctoi=0;
		}
		if(befctoi==0&&ctoi==1)//������
		{
			wei[count]=a[i]-'0';
			befctoi=1;
			count++;
		}
		else if(befctoi==1&&ctoi==1)//��λ
		{
			wei[count]=a[i]-'0';
			count++;
		}
		else if(befctoi==1&&ctoi==0)//�½���
		{
			for(j=0;j<count;j++)
			{
				num[times]+=wei[j]*pow(10,count-j-1);
			}
			times++;
			befctoi=0;
			count=0;
		}
	}

	for(i=0;i<times;i++)
	{
		printf("a[%d]=%d\n",i,num[i]);
	}
	for(i=0;i<times;i++)
    {
        printf("%c",'a'+num[i]-1);
    }

	return 0;
}
/*a1z26���ܷ�������ĸ��ת��Ϊ1~26������*/
//15-11-8-6-9-8-19-6
//okhfihsf
//3-5-9
//cei
